#include<stdio.h>

void main()
{
	char str[20];
	printf("enter any character :");
	scanf("%s",&str);
	
	int i;
	
	for(i=0;i<20;i++)
	{
	if(str[i]>=65 && str[i]<=90)
	{
		str[i]=str[i]+32;
	}
	else
	{
		str[i]=str[i]-32;
	}
	}printf("converted string :%s",str);
}
