#include<stdio.h>
#include<math.h>

int main()
{
    float l;
    printf("enter the value of l :");
    scanf("%f",&l);


    if(l<0)
    {
    	printf("enter length in possitive number");
	}

	else
	{
    printf("dioganal of square is %f",sqrt(2)*l);
    }
    return 0;
}
