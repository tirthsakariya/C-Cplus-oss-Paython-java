#include<stdio.h>
#include<conio.h>
void main()
{
	int n,i,j;
	clrscr();
	printf("enter a number of table:");
	scanf("%d",&n);

	for(i=1;i<=10;i++)
	{
		printf("table of %d :\n",i);
		for(j=1;j<=10;j++)
		{
		printf("%d %d = %d\n",n,i,n*i);
		}
		printf("\n");
	}


	getch();
}