#include<stdio.h>

void mycube();

void mycube()
{
	int n,i;
	
	printf("enter array size :");
	scanf("%d",&n);
	
	int a[i];
	int *p[i];
	
	for(i=0;i<n;i++)
	{
		p[i] = &a[i];
	}
	
	for(i=0;i<n;i++)
	{
		printf("enter a[%d] :");
		scanf("%d",p[i]);
	}
	
	for(i=0;i<n;i++)
	{
		printf("cube a[%d] :\n",i,a*a*a,*p[i]);
	}
}
void main()
{
	mycube();
}
