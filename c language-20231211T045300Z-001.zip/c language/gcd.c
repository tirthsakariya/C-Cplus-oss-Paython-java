#include<stdio.h>

int findgcd(int a,int b)
{
	while(b!=0)
	{
		int temp = b;
			b = a%b;
			a= temp;
	}
 return a;
}

void main()
{
	int n1,n2,gcd;
	
	printf("enter the value of a & b :");
	scanf("%d %d",&n1,&n2);
	
	gcd = findgcd(n1,n2);
	
	printf("gcd of %d & %d is %d",n1,n2,gcd);
}
