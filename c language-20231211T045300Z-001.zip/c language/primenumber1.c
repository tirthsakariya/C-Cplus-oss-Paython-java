#include <stdio.h>
#include<stdbool.h>

bool prime(int n)
{
	int i;
	if(n==1||n==0)
	{
		return false;
	}
	for(i=2;i<=n/2;i++)
	{
		if(n%1==0)
		{
			return false;
		}
	return true;
	}
}
int main()
{
	int n,i;
	printf("enter end value of number :");
	scanf("%d",&n);
	
	if(prime(i);)
	{
		printf("%d",i)
	}
	return 0;
}

