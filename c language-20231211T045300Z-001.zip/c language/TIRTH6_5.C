#include<stdio.h>
#include<conio.h>
void main()
{
	int i,n;
	clrscr();
	printf("enter the first year:");
	scanf("%d",&i);
	printf("enter the second year:");
	scanf("%d",&n);

	while(i+=4)
	{
	printf("%d",&i);
	}
getch();
}
