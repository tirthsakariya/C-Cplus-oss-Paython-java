#include<stdio.h>

int main()
{
    int l,b;
    printf("enter the value of l :");
    scanf("%d",&l);
    printf("enter the value of b :");
    scanf("%d",&b);

    if(l<0 && b<0)
    {
    	printf("enter length and breath in possitive number");
	}
	
	else if(b<0)
	{
		printf("enter breath in possitive number");
	}
	else if(l<0)
	{
		printf("enter length value in possitive number");
	}
	else
	{
    printf("area of ractangle is %d",l*b);
    }
    return 0;
}
