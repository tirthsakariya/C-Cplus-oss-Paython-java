#include<stdio.h>

	void main(){
	FILE *f1;
	FILE *f2;

	f1=fopen("C:\\Users\\r34\\Desktop\\file1.txt","a");
	f2=fopen("C:\\Users\\r34\\Desktop\\file2.txt","w");
	
	char f3[20],f4[20];
	fprintf(f1,"hello hello world");
	fprintf(f2,"%s",*f1);
}