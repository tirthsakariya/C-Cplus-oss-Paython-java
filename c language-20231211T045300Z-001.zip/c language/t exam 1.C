#include<stdio.h>
#include<conio.h>

main()

{
   int a,b,c;
   clrscr();
   printf("first angle a :");
   scanf("%d",&a);
   printf("second angle b :");
   scanf("%d",&b);
   c = 180 - (a+b);
   printf("answer : %d",c);
   getch();
}