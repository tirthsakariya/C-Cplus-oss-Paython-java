#include<stdio.h>

void main()
{
	int a[10],large,i;
	
	printf("enter the elements of the array :");
	
	for(i=0;i<10;i++)
	{		
	scanf("%d",&a[i]);
	}
	
    large =a[0];
    
    for(i=1;i<=10;i++)
    {
    	if (a[i]>large)
    	{
    		large=a[i];
		}
	}
	printf("large is %d",large);
}
