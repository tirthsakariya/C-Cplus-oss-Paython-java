#include<stdio.h>
#include<conio.h>
void main()
{int n;
  clrscr();
  printf("enter number:");
  scanf("%d",&n);

  if(n>0)
  {
  printf("it 's a positive number");
  }
  else if(n==0)
  {
  printf("it 's a nuteral number");
  }
  else
  {
  printf("it 's a nagative number");
  }
  getch();
}