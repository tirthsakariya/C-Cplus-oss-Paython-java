#include<stdio.h>
#include<conio.h>
void main()
{
	int x=0,y=1,z,n,i;
	clrscr();
	printf("enter a number:");
	scanf("%d",&n);

	for(i=1;i<=n;i++)
	{
		printf("%d\n",x);
		z=x+y;
		x=y;
		y=z;
	}

	getch();
}