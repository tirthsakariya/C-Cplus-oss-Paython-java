#include<stdio.h>
#include<conio.h>

main()

{
   int a,b,c,d;
   clrscr();
   printf("enter value of a :");
   scanf("%d",&a);
   printf("enter value of b :");
   scanf("%d",&b);
   printf("enter value of c :");
   scanf("%d",&c);
   printf("enter value of d :");
   scanf("%d",&d);

   if(a>b)
   {
	if(a>c)
	{
	     printf("a is maximum");
	}
	  else
	  {
	     printf("c is maximum");
	  }
	     if(a>d)
	     {
		  printf("a is maximum");
	     }
	  else
	   {
		  printf("d is maximum");
	   }
    }
   getch();
}




