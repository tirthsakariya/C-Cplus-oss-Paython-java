#include<stdio.h>
#include<conio.h>
main()
{
	int i=1;
	clrscr();

	while(i<=10)
	{
		printf("%d",i);
		i++;
	}
	getch();
}


