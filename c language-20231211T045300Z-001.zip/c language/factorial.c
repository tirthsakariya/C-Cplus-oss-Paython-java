#include<stdio.h>

int main()
{
	int num;
	int factorial=1;
	
	printf("enter the number :");
	scanf("%d",&num);
	
	while(num > 0)
	{
		factorial = factorial * num ;
	     num--;   	
	}
	printf("factorial = %d",factorial);
	
	return 0;
}
