#include<stdio.h>
#include<conio.h>
void main()
{
	char i='a';
	clrscr();

	do

		{
		printf("%c\t",i);
		i=i+3;
		i++;
	}while(i<='z');
	getch();
}