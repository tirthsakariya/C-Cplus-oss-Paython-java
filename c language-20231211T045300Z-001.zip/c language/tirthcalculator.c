#include<stdio.h>
void calculator()
{
	char choice;
	int num1,num2;
	printf("enter the choice between +,-,*,/, % :");
	scanf("%c",&choice);
	printf("enter the value of num1 and num2 :");
	scanf("%d %d",&num1,&num2);
	switch(choice)	{
		case '+':
			printf("adittion is %d",num1 + num2);
			break;
		case '-':
			printf("substraction is %d",num1-num2);
			break;
		case '*':
			printf("multiplication is %d",num1*num2);
			break;
		case '/':
			printf("division is %d",num1/num2);
			break;
		case '%':
			printf("modulus is %d",num1%num2);
			break;
		default :
			printf("invalid input plz try again");
			break;}
}
int main(){
	calculator();
		return 0;
		}

