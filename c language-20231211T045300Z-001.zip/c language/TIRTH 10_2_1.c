#include<stdio.h>

int arraysum(int a[],int n)
{
	int sum=0,i;
	for(i=0;i<n;i++)
	{
		sum += a[i];
	}
	return sum;
}

void arrayinput(int a[],int n)
{
	int i;
	
	for(i=0;i<n;i++)
	{
		printf("enter a[%d]:",i);
		scanf("%d",&a[i]);
	}
}

void main()
{
	array input a[n],i,sum;
	arraysum(a,n);
	arrayinput(a,n);
}
