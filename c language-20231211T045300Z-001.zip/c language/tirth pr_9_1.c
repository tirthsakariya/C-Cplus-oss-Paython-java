#include<stdio.h>

int main ()
{
	char n;
	int i,count=0;
	int *p;
	
	p=&n;
	
		printf("enter any string :");
		scanf("%s",p);
		
	
	for(i=0;i<n;i++)
	{
		printf("length of string :%d",p);
		count++;
	}
}
