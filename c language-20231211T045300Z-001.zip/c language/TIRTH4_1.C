stdio.h>
#include<conio.h>
void main()
{
  float p,r,n,interest;
  clrscr();
  p=500;
  r=5;
  n=2;
  interest=(p*r*n)/100;
  printf("area of circle :%.2f",interest);
  getch();
  }

