#include<stdio.h>
#include<conio.h>
main()

{
	int n;
	clrscr();
	printf("enter ending point\t:");
	scanf("%d",&n);

	while(n>=1)
	{
	printf("\n\t%d",n);
	n--;
	}
 getch();
}