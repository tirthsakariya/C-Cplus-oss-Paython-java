#include<stdio.h>

void main()
{
	int i;
	FILE *A1;
	FILE *A2;
	
	A1 = fopen("C:\\Users\\123\\Desktop\\odd_file.txt","w");
	A2 = fopen("C:\\Users\\123\\Desktop\\even_file.txt","w");
	
	for(i=50;i<=70;i++)
	{
		if(i%2==0)
		{
			printf(A2,"%d",i);
		}
		else
		{
			printf(A1,"%d",i);
		}
	}
}
