#include<stdio.h>
#include<math.h>
#define pi 3.14

int main()
{
    float r,h;
    printf("enter the value of r & h :");
    scanf("%f %f",&r,&h);


    if(r<0&&h<0)
    {
    	printf("enter radius and hight in possitive number");
	}
	else if(r<0)
	{
		printf("enter radius in possitive number");
	}
	else if(h<0)
	{
		printf("enter hight in possitive number ");
	}
	else
	{
    printf("area of cylinder is %f",(2*pi*r*h)+(2*pi*pow(r,2)));
    }
    return 0;
}
