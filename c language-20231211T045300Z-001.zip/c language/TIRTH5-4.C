#include<stdio.h>
#include<conio.h>
void main()
{
int a,b,c,d;
clrscr();
printf("enter value of a:");
scanf("%d",&a);
printf("enter value of b:");
scanf("%d",&b);
printf("enter value of c:");
scanf("%d",&c);
printf("enter value of d:");
scanf("%d",&d);

(a>b)
     ?(a>c)
	   ?printf("a is maximum")
	   :printf("c id maximum")
     :(a>d)
	   ?printf("a is maximum")
	   :printf("d is maximum");
(b>c)
     ?(b>d)
	   ?printf("b is maximum")
	   :printf("d is maximum")
     :(b>a)
	   ?printf("b is maximum")
	   :printf("a is maximum");
(c>d)
     ?(c>a)
	   ?printf("c is maximum")
	   :printf("a is maximum")
     :(c>b)
	   ?printf("c is maximum")
	   :printf("b is maximum");
(d>a)
     ?(d>b)
	   ?printf("d is maximum")
	   :printf("b is maximum")
     :(d>c)
	   ?printf("d is maximum")
	   :printf("c is maximum");
 getch();
 }
