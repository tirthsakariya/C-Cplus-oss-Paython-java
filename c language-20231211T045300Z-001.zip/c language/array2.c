#include<stdio.h>

void main()
{
	int i,num,a[num];
	
	printf("enter the elements of the array :");
	scanf("%d",&num);
	
	for(i=0;i<num;i++)
	{		
	printf("enter a[%d] :",i);
	scanf("%d",&a[i]);
	}
	
	for(i=0;i<num;i++)
	{
		printf("a[%d] : %d",i,a[i]);
	}
}
