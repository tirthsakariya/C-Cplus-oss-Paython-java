#include<stdio.h>

void myNumber();

void myNumber()
{
	int a;
	
	printf("enter any number :");
	scanf("%d",&a);
	
	if(a%3==0 || a%5==0)
	{
		printf("The given number is divisible by both 3 or 5");
	}
	else
	{
		printf("the given number is not divisible by both 3 or 5");
	}
}

void main()
{
	myNumber();
}
