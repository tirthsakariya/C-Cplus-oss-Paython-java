#include<stdio.h>

struct student
{
	int id;
	char name[20];
	int age;
	char course[20];
	char city[20];
	int standard;
	char school[20];
};
void main()
{
	int n,i;
	
	printf("enter number of student :");
	scanf("%d",&n);
	
	struct student s;
	
	for(i=0;i<n;i++)
	{
	printf("enter id\t:");
	scanf("%d",&s.id);
	
	printf("enter name\t:");
	scanf("%s",&s.name);
	
	printf("enter age\t:");
	scanf("%d",&s.age);
	
	printf("enter course\t:");
	scanf("%s",&s.course);
	
	printf("enter city\t:");
	scanf("%s",&s.id);
	
	printf("enter standard\t:");
	scanf("%d",&s.standard);
	
	printf("enter school\t:");
	scanf("%s",&s.school);
    }	
    
	printf("\n\n\nid\tname\tage\tcourse\tcity\tstandard\tschool\n==== ==== ==== ==== ==== ==== ====\n");
	
	for(i=0;i<n;i++)
	{
	printf("%d\t%s\t%d\t%s\t%s\t%d\t%s",s.id,s.name,s.age,s.course,s.city,s.standard,s.school);
	}
	
}

