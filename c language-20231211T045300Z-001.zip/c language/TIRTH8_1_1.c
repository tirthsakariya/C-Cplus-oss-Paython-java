#include<stdio.h>

void main()
{

int n;
printf("enter n:");
scanf("%d",&n);

int a[n],i;
for(i=0;i<5;i++)
{
	printf("Enter a[%d]:",i);
	scanf("%d",&a[i]);
}

for(i=0;i<5;i++)
{
	printf("a[%d]:%d",i,a[i]);
}
}
