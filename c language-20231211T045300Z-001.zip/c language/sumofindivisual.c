#include<stdio.h>

int main()
{
	int num,m,sum;
	printf("enter the possitive value for indivisual integer : ");
	scanf("%d",&num);
	
	while(num != 0)
	{
		m = num % 10;
		sum += m;
		num = num /10;
	}
	printf("sum of indivisual integer is %d",sum);
	return 0;
}
