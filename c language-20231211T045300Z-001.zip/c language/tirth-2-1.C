#include<stdio.h>
#include<conio.h>
main()
{
	int a;
	clrscr();

	printf("enter the number");
	scanf("%d",&a);

	(a%2==0)
		?printf("your given number is evan")
		:printf("your given numbet is odd);
		getch();
}