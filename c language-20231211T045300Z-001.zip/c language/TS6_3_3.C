#include<stdio.h>
#include<conio.h>

void main()
{
	int n,i;
	clrscr();
	printf("enter a number of table :");
	scanf("%d",&n);

	for(i=1;i<=10;i++)
	{
	printf("%d * %d = %d\n",n,i,n*i);
	}
	getch();
}