#include<stdio.h>

int a;
int *p;

void input(int a[],int n)
{
	int i;
	printf("enter array size :");
	scanf("%d",&n);
	
	for(i=0;i<n;i++)
	{
		printf("a[%d]:",i);
		scanf("%d",&a[i]);
	}
	
	printf("reverse of array\n");
	
	for(i=0;i<n;i++)
	{
		printf("%d\t",a[n-1-i]);
	}
}

void main()
{
	int n,a[n];
	input(a,n);
}

