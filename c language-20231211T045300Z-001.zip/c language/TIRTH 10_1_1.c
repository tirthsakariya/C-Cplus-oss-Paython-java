#include<stdio.h>

void myCube();

void myCube()
{
	int a;
	
	printf("enter a :");
	scanf("%d",&a);
	
	printf("cube :%d\n",a*a*a);
}
void main()
{
	myCube();
}
