#include<stdio.h>

void main()
{
	int r,c;
	
	printf("enter the number of array :");
	sacnf("%d",&r);
	printf("enter the number of column :");
	scanf("%d",&c);
	
	int a[r][c],i,j;
	float d,sum=0,b;
	
	for(i=0;i<r;i++)
	{
		for(j=0;j<c;j++)
		{
			printf("a[%d][%d] : ",i,j);
			scanf("%d",&a[i][j]);
			sum += a[i][j];
		}
	}
	
	printf("\n");
	b=i*j;
	d=sum/b;
			
	printf("avrage of 2D array :%f",d);	
}
