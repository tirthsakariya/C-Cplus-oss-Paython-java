#include<stdio.h>
#include<math.h>

int main()
{
	float d,l,w;
	
	printf("enter the value of l & w :");
	scanf("%f %f",&l,&w);
	
	d=sqrt(pow(l,2)+pow(w,2));
	
	printf("diagonal of ractangle is %f",d);
	
	return 0;
	
	
}
