#include<stdio.h>

/* Function Prototype */
void mystrlwr(char str[40]);

/* Main Function */
int main()
{
 char str[40];
 int i;

 printf("Enter string:\n");
 gets(str);
 mystrlwr(str);
 printf("String in uppercase is:\n");
 puts(str);
 
 return 0;
}

/* Function Definition */
void mystrlwr(char str[40])
{
 int i;
 for(i=0;str[i]!='\0';i++)
 {
  if(str[i]>='a'&& str[i]<='z')
  {
   str[i] = str[i]-32;
  }
 }
}
