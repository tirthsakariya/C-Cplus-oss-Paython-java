#include<stdio.h>

void main()
{
	char name[20],cpy[20];
	int i,cmp;
	
	printf("enter  any string :");
	gets(name);
	
	strcmp(cpy,name);
	strrev(name);
	cmp=strcmp(name,cpy);
	
	if(cmp=0)
	{
		printf("string is palindrom ....");
	}
	else
	{
		printf("string is not palindrom....");
	}
}
