#include<stdio.h>

struct employ
{
	int id;
	char name[20];
	char address[20];
	char email[20];
	int salary;
	char role[20];
};
void main()
{
	int n,i;
	
	printf("enter number of employ :");
	scanf("%d",&n);
	
	struct employ s[n];
	
	for(i=0;i<n;i++)
	{
	printf("employ :%d/%d\n",i+1,n);
		
	printf("enter id\t:");
	scanf("%d",&s[i].id);
	
	printf("enter name\t:");
	scanf("%s",&s[i].name);
	
	printf("enter address\t:");
	scanf("%s",&s[i].address);
		
	printf("enter email\t:");
	scanf("%s",&s[i].email);
	
	printf("enter salary\t:");
	scanf("%d",&s[i].salary);
	
	printf("enter role\t:");
	scanf("%s",&s[i].role);
    }	
    
	printf("\n\n\nid\tname\taddress\temail\tsalary\trole\n==== ==== ==== ==== ==== ==== ==== ====\n");
	
	for(i=0;i<n;i++)
	{
	printf("%d\t%s\t%s\t%s\t%d\t%s\t",s[i].id,s[i].name,s[i].address,s[i].email,s[i].salary,s[i].role);
	}
	
}

