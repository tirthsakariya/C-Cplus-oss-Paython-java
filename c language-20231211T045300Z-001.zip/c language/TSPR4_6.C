#include<stdio.h>
#include<conio.h>

void main()
{
	int i,j,s;
	clrscr();

	for(i=5;i>=1;i--)
	{
	  for(s=1;s<=i-1;s++)
	  {
	  printf(" ");
	  }
	   for(j=i;j<=5;j++)
	   {
	     printf("%d",j);
	   }
	   for(j=i;j<=5;j++)
	   {
	      printf("%d",j);
	   }
	   for(s=1;s<=i-1;s++)
	   {
	     printf(" ");
	   }
	   printf("\n");
	}
	getch();
}