#include<stdio.h>
#include<conio.h>
main()
{
	clrscr();
	printf("*\n");
	printf("*\n");
	printf("*\n");
	printf("*     **         *\n");
	printf("*    *  *       *\n");
	printf("*   *    *     *\n");
	printf("*  *      *   *\n");
	printf("* *        * *\n");
	printf("*\n");
	getch();
}


