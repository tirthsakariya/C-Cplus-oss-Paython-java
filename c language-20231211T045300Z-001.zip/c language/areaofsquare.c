#include<stdio.h>

int main()
{
    int l;
    printf("enter the value of l :");
    scanf("%d",&l);


    if(l<0)
    {
    	printf("enter length in possitive number");
	}

	else
	{
    printf("area of square is %d",l*l);
    }
    return 0;
}
