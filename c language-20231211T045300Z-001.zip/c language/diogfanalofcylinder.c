#include<stdio.h>
#include<math.h>
#define pi 3.14

int main()
{
    float r,h;
    printf("enter the value of r & h :");
    scanf("%f %f",&r,&h);


    if(r<0&&h<0)
    {
    	printf("enter radius and hight in possitive number");
	}
	else if(r<0)
	{
		printf("enter radius in possitive number");
	}
	else if(h<0)
	{
		printf("enter hight in possitive number ");
	}
	else
	{
    printf("dioganal of cylinder is %f",sqrt(4*pow(r,2)*pow(h,2)));
    }
    return 0;
}
