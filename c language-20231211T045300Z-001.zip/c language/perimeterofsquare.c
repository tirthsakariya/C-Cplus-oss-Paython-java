#include<stdio.h>

int main()
{
    int l;
    printf("enter the value of l :");
    scanf("%d",&l);


    if(l<0)
    {
    	printf("enter length in possitive number");
	}

	else
	{
    printf("perimeter of square is %d",4*l);
    }
    return 0;
}
