#include<stdio.h>
#include<conio.h>
void main()
{
 int choice;
 clrscr();
 printf("Enter....\n");
 printf("1 for english\n");
 printf("2 for hindi\n");
 printf("3 for gujarati\n");
 printf("Enter your choice :");
 scanf("%d",&choice);

 switch(choice)
 {
	case 1:
		printf("\nyou have selacted english\n");

		printf("Enter....\n");
		printf("press 1 for internet recharge\n");
		printf("press 2 for top recharge\n");
		printf("press 3 for special recharge\n");
		printf("Enter your choice :");
		scanf("%d",&choice);
		printf("\n\nyou have successfully done your recharge");
		break;
	case 2:
		printf("\nyou have selacted hindi\n");

		printf("Enter....\n");
		printf("internet recharge ke liye 1 dabaiye\n");
		printf("top up recharge ke liye 2 dabaiye\n");
		printf("special recharge ke liye 3 dabaiye\n");
		printf("Enter your choice :");
		scanf("%d",&choice);
		printf("\n\nApne safaltapurvak richarge karva liya he");
		break;
	case 3:
	       printf("\nyou have selacted gujarati\n");
	       printf("internet recharge mate 1 dabavo\n");
	       printf("top up recharge mate 2 dabavo\n");
	       printf("special recharge mate 3 dabavo\n");
	       printf("Enter your choice :");
	       scanf("%d",&choice);
	       printf("\n\ntame safltapurvak recharge karavyu che");
	       break;
  }
 getch();
}