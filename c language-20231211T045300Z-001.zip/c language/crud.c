#include <stdio.h>

// Function to create an array
void createArray(int arr[], int size) {
    printf("Enter %d elements:\n", size);
    for (int i = 0; i < size; i++) {
        scanf("%d", &arr[i]);
    }
}

// Function to display the array
void displayArray(int arr[], int size) {
    printf("Array elements:\n");
    for (int i = 0; i < size; i++) {
        printf("%d ", arr[i]);
    }
    printf("\n");
}

// Function to update an element in the array
void updateElement(int arr[], int size) {
    int index, newValue;
    printf("Enter the index of the element to update (0 to %d): ", size - 1);
    scanf("%d", &index);
    
    if (index >= 0 && index < size) {
        printf("Enter the new value: ");
        scanf("%d", &newValue);
        arr[index] = newValue;
        printf("Element updated successfully.\n");
    } else {
        printf("Invalid index.\n");
    }
}

// Function to delete an element from the array
void deleteElement(int arr[], int* size) {
    int index;
    printf("Enter the index of the element to delete (0 to %d): ", *size - 1);
    scanf("%d", &index);
    
    if (index >= 0 && index < *size) {
        for (int i = index; i < *size - 1; i++) {
            arr[i] = arr[i + 1];
        }
        (*size)--;
        printf("Element deleted successfully.\n");
    } else {
        printf("Invalid index.\n");
    }
}

int main() {
    int arr[100], size;
    int choice;
    
    printf("Enter the size of the array: ");
    scanf("%d", &size);
    
    createArray(arr, size);
    
    do {
        printf("\nCRUD Operations on 1D Array\n");
        printf("1. Display Array\n");
        printf("2. Update an Element\n");
        printf("3. Delete an Element\n");
        printf("4. Exit\n");
        printf("Enter your choice (1-4): ");
        scanf("%d", &choice);
        
        switch (choice) {
            case 1:
                displayArray(arr, size);
                break;
            case 2:
                updateElement(arr, size);
                break;
            case 3:
                deleteElement(arr, &size);
                break;
            case 4:
                printf("Exiting program.\n");
                break;
            default:
                printf("Invalid choice. Please try again.\n");
        }
    } while (choice != 4);
    
    return 0;
}