#include<stdio.h>
#include<conio.h>
void main ()
{
	 int a;
	 clrscr();
	 printf("Enter any number :");
	 scanf("%d",&a);
	 (a%2==1)
		 ?printf("this is odd number")
		 :printf("this is even number");
	getch();
}