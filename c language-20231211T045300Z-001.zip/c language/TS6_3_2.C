#include<stdio.h>
#include<conio.h>

void main()
{
	int n,fact=1;
	clrscr();
	printf("enter any value for factoprial:");
	scanf("%d",&n);

	while(n>=1)
	{
		fact*=n;
		n--;
	}
	printf("%d",fact);
	getch();
}