#include<stdio.h>
#include<conio.h>
main()

{
	int i=1,n;
	clrscr();
	printf("enter ending point\t:");
	scanf("%d",&n);

	while(i<=n)
	{
	printf("\n\t%d",i);
	i++;
	}
 getch();
}