#include<stdio.h>
#include<conio.h>
void main()
{
 int a,b,c;
 clrscr();
 printf("enter a value of first number");
 scanf("%d",&a);
 printf("enter a value of second number");
 scanf("%d",&b);
 printf("enter a value of third number");
 scanf("%d",&c);

(a<b)
     ?(a<c)
	   ? printf("a is minimum")
	   : printf("c is minimum")
     :(b<c)
	   ? printf("b is minimum")
	   : printf("c is minimum");
getch();
}