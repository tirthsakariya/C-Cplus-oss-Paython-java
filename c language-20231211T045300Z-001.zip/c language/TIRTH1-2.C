#include<stdio.h>
#include<conio.h>

main()
{
 clrscr();
 printf("name\t : tirth sakariya\n");
 printf("class\t: 12 science\n") ;
 printf("course\t:c language\n");
 printf("hobby\t:\"coding\"\n");
 printf("contact no\t\t:9453749423\n");
 printf("location\t\t:red and white\n");
 printf("school\t:ashadeep iit\n");
 printf("city\t:surat\n");
 getch();
 }