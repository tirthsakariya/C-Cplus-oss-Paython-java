#include<stdio.h>
#include<conio.h>
main()

{
       float c,f;
	clrscr();
	printf("enter value of c:");
	scanf("%2f",&c);
	f = (c *(9/5)+32);
	printf("answer : %.2f",f);
	getch();
}