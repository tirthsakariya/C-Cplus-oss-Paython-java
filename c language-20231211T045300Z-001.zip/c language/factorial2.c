#include<stdio.h>

int fact(int n)
{
	if(n==0)
	  return 1;
	  
	else
	  return (n*fact(n-1));
}

void main()
{
	int num,factorial;
	
	printf("enter the number :");
	scanf("%d",&num);
	
	factorial = fact(num);
	
	printf("factorial =%d",factorial);
}
