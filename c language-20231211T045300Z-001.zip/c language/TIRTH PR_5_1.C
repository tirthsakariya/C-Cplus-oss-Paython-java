#include<stdio.h>

int main()
{
	int n;
	printf("enter the array 's size :");
	scanf("%d",&n);
	
	int a[n],i;
	
	for(i=0;i<n;i++)
	{
		printf("enter a[%d]:",i);
		scanf("%d",&a[i]);
	}
	for(i=0;i<n;i++)
	{
		if(a[i]<0)
		{
			printf("the naggative array :%d",a[i]);
		}
		else
		{
			printf(" ");
			
		}
	}
}
